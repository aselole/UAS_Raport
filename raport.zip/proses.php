<?php
session_start();
include "config.php";
error_reporting(0);

if (empty($_SESSION['nis']) AND empty($_SESSION['password'])){include "profil.php";}
else{
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Selamat Datang!</title>
<style type="text/css">
body h2 {
	color: #FFF;
}
</style>
</head>
<body>

<?php
$sql = mysql_query("SELECT * FROM login WHERE user_id = '$_SESSION[user_id]'");
while ($data = mysql_fetch_array($sql))
{
 $user_nama = $data['user_nama'];
 $user_akses = $data['user_akses'];
}
?>
<h2>Selamat Datang <?php echo "$user_nama"; ?>!</h2>
<h2>Anda Login sebagai : <?php echo "$user_akses"; ?>!</h2>
<?php
if ($_SESSION[user_akses] == "Murid") {include "raportsiswa.php";}
if ($_SESSION[user_akses] == "Guru IPA"){include "nilaiipa.php";}
if ($_SESSION[user_akses] == "Guru MAT"){include "nilaimat.php";}
if ($_SESSION[user_akses] == "Guru Bhs Ind"){include "nilaiind.php";}
if ($_SESSION[user_akses] == "Guru Bhs Inggris"){include "nilaiing.php";}
if ($_SESSION[user_akses] == "Guru Jurusan"){include "nilaijurusan.php";}
if ($_SESSION[user_akses] == ""){echo "Kamu tidak memiliki akses kesini! <a href='home.php' title='KEMBALI!'>KEMBALI</a>";}

?>
</body>
</html>
<?php } ?>