<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<link rel="shortcut icon" href="favicon.ico">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<title>Raport Online</title>
<link rel="stylesheet" href="style.css" type="text/css" charset="utf-8" />
</head>
<body>
<div id="wrapper">
  <div id="header">
    <div>
      
    </div>
  </div>
  <div id="nav"> <a href="home.php">Home</a> <a href="prestasi.php">Prestasi</a><a href="profil.php">Kegiatan Baru</a> <a href="raport.php">Raport</a><span class="more"><a href="visidanmisi.php">Visi $ Misi</a></span>   </div>
  <div id="body">
    <div id="body-top">
      <div id="body-bot">
        <div class="clear">
        <h2><p> Prestasi Sekolah         </p></h2>
<p> 1. Pengiriman Siswa Mewakili Indonesia Ke Jepang Dalam Rangka Pertukaran Pelajar Tingkat
  Internasional Tahun 2008-2009</p>
       <p> 2. Pengiriman Tim SPPN Sebagai Kontingen Jawa Timur Dalam Tekarsistanas X Ke Kalimantan
         Selatan Meraih Juara III Lomba Diskusi Tingkat Nasional         </p>
       <p>3. Anggota Paskibraka Tingkat Kabupaten         </p>
       <p>4. Lulusan SPPN Diterima Sebagai THL-PB Deptan dan PNS Departemen Pertanian.         </p>
       <p>5. Kuliah di Universitas Negeri Dan Swasta Ternama : Universitas Brawijaya, UGM,</p>
       <p> 6. Meraih Kejuaraan Dalam Lomba Kesenian, Olahraga (Bola Volly), Lomba Majalah Dinding,
         dsb. </p>
</body>
</html>
</div>
      </div>
    </div>
  </div>
  <div id="foot">
    <div id="foot-top">
      <div id="foot-bot">
        <div class="clear"></div>
      </div>
    </div>
  </div>
  <div id="footer">
    <p>&copy; SMK NEGERI 1 TULUNGAGUNG COPYRIGHT 2014</p>
  </div>
</div>
</body>
</html>
