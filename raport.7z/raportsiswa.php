<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<link rel="shortcut icon" href="favicon.ico">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<title>Raport Online</title>
<link rel="stylesheet" href="style.css" type="text/css" charset="utf-8" />
</head>
<body>
<div id="wrapper">
  <div id="header">
    <div>
      
    </div>
  </div>
<div id="nav"> <a href="home.php">Home</a> <a href="prestasi.php">Prestasi</a><a href="profil.php">Kegiatan Baru</a> <a href="raport.php">Raport</a><span class="more"><a href="visidanmisi.php">Visi $ Misi</a> <a href="logout.php">Log out</a></span></div>
<div id="body">
    <div id="body-top">
      <div id="body-bot">
        <div class="clear">

<table width="400" border="0" align="center" cellpadding="2" cellspacing="1" bgcolor="#000000" celpading="2" celspacing="1" > 
  <tr bgcolor="#CCFFFF"> 
  
    <td><div align="center"><strong>Matematika</strong></div></td> 
    <td><div align="center"><strong>Bhs Ind</strong></div></td> 
    <td><div align="center"><strong>Bhs Inggris</strong></div></td>   
    <td><div align="center"><strong>IPA</strong></div></td>
    <td><div align="center"><strong>Jurusan</strong></div></td> 
  </tr> 

   <tr bgcolor="#FFFFFF"> 

    <td height="22">
    <form action="viewmat.php" method="post" id="form1"><center>
        <p>
          <input type="submit" name="Submit" id="button" value="LIHAT!!!"/>  
        </p></center>
     </form></td>
 <td>
 <form id="form2" method="post" action="viewind.php"><center>
 <p>
     <input type="submit" name="Submit" id="button2" value="LIHAT!!!" /></p></center>
   
 </form></td>
 <td> <form id="form3" method="post" action="viewing.php"><center>
 <p>
     <input type="submit" name="Submit" id="button3" value="LIHAT!!!" /></p></center>
   
 </form></td>
 <td><form id="form4" method="post" action="viewipa.php"><center>
 <p>
     <input type="submit" name="Submit" id="button4" value="LIHAT!!!" /></p></center>
 </form></td>
<td><form id="form5" method="post" action="viewjurusan.php"><center>
 <p>
     <input type="submit" name="Submit" id="button5" value="LIHAT!!!" /></p></center>
 </form></td>

  </tr> 
 
</table>





</body>
</html>
</div>
      </div>
    </div>
  </div>
  <div id="foot">
    <div id="foot-top">
      <div id="foot-bot">
        <div class="clear"></div>
      </div>
    </div>
  </div>
  <div id="footer">
    <p>&copy; SMK NEGERI 1 TULUNGAGUNG COPYRIGHT 2014</p>
  </div>
</div>
</body>
</html>
