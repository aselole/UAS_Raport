<?php
    include "config.php";
    $nis=$_POST['nis'];
    $password = md5($_POST['password']);
    
    $login = mysql_query("SELECT * FROM login WHERE nis='$nis' AND password='$password'");
    $hasil = mysql_num_rows($login);
    $r = mysql_fetch_array($login);
    
    if ($hasil > 0)
    {
      session_start();
      session_register("user_id");
      session_register("nis");
      session_register("password");
      session_register("user_akses");
	  session_register("alamat");
	  session_register("notelp");
      $_SESSION[user_id]     = $r[user_id];
      $_SESSION[nis]         = $r[nis];
      $_SESSION[password]     = $r[password];
      $_SESSION[user_akses]    = $r[user_akses];
	  $_SESSION[alamat]			= $r[alamat];
	  $_SESSION[notelp]			= $r[notelp];
      header('location:proses.php');
    }
	
    
    else{ echo "LOGIN GAGAL! <br> <a href='profil.php'><< Kembali</a>"; }
?>