<body>
<?php
mysql_connect("localhost","root","");
mysql_select_db("raport");
extract($_POST);
mysql_query ("update nilaimat set nama='$nama',nilai_matematika='$nilai_matematika' where id='$id' ");


/*echo"<script>document.location.href='2.php?a=data&nama=$nama'</script>";*/
echo "<center>Nilai Berhasil di Input<center>";  
    echo "<center><h3><a href=nilaimat.php>Lihat Nilai</a></h3></center>";  

;

?>
</body>