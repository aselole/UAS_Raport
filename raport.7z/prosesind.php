<body>
<?php
mysql_connect("localhost","root","");
mysql_select_db("raport");
extract($_POST);
mysql_query ("update nilaiind set nama='$nama',nilai_ind='$nilai_ind' where id='$id' ");


echo "<center>Nilai Berhasil di Input<center>";  
    echo "<center><h3><a href=nilaiind.php>Lihat Nilai</a></h3></center>";  


?>
</body>