<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<link rel="shortcut icon" href="favicon.ico">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<title>Raport Online</title>
<link rel="stylesheet" href="style.css" type="text/css" charset="utf-8" />
</head>
<body>
<div id="wrapper">
  <div id="header">
    <div>
      
    </div>
  </div>
  <div id="nav"> <a href="home.php">Home</a> <a href="prestasi.php">Prestasi</a><a href="profil.php">Kegiatan Baru</a> <a href="raport.php">Raport</a><span class="more"><a href="visidanmisi.php">Visi $ Misi</a></span>  </div>
  <div id="body">
    <div id="body-top">
      <div id="body-bot">
        <div class="clear">
        <p>&nbsp; </p>
        <h2>SEKOLAH MENENGAH KEJURUAN NEGERI 1 TULUNGAGUNG</h2>  
        <p> Alamat: Jln. Raya Boyolangu Km.5 Tulungagung          </p>
        <p>Telp./fax. : (0355) 325853</p>
        <p> Email : smkn1tulungagung@gmail.com</p>
        <p>Alih Fungsi dari :
          SPP Negeri 1 Tulungagung (Per-1 Januari 2010)          </p>
<p>Program Keahlian </p>
        <p>1. Abri bisnis Tanaman Pangan Dan Hortikultura</p>
        <p> 2. Agribisnis Ternak Unggas          </p>
        <p>3. Agribisnis Ternak Ruminansia (Baru)          </p>
        <p>4. Agribisnis Perikanan (Baru)</p>
</body>
</html>
</div>
      </div>
    </div>
  </div>
  <div id="foot">
    <div id="foot-top">
      <div id="foot-bot">
        <div class="clear"></div>
      </div>
    </div>
  </div>
  <div id="footer">
    <p>&copy; SMK NEGERI 1 TULUNGAGUNG COPYRIGHT 2014</p>
  </div>
</div>
</body>
</html>
